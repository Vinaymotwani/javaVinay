import Common "../types/common";
import UserTypes "../types/users";
import UserLib "../lib/users";
import Time "mo:core/Time";

mixin (
  usersState : UserLib.State,
) {
  public shared ({ caller }) func setUserRole(
    target : Common.UserId,
    role : Common.Role,
    buildingId : ?Common.BuildingId,
    wardId : ?Common.WardId,
  ) : async () {
    if (not UserLib.isAdmin(usersState, caller)) {
      return;
    };
    UserLib.setUserRole(usersState, caller, target, role, buildingId, wardId);
  };

  public shared query ({ caller }) func getMyProfile() : async ?UserTypes.UserRecord {
    // Auto-register caller if not found, then return profile
    UserLib.getUser(usersState, caller);
  };

  public shared ({ caller }) func registerMe() : async UserTypes.UserRecord {
    switch (UserLib.getUser(usersState, caller)) {
      case (?existing) existing;
      case null {
        let newUser : UserTypes.UserRecord = {
          id = caller;
          role = #manager;
          buildingId = null;
          wardId = null;
          createdAt = Time.now();
        };
        usersState.users.add(caller, newUser);
        newUser;
      };
    };
  };

  public shared query ({ caller }) func getUserProfile(
    target : Common.UserId,
  ) : async ?UserTypes.UserRecord {
    if (not UserLib.isAdmin(usersState, caller)) return null;
    UserLib.getUser(usersState, target);
  };

  public shared query ({ caller }) func listUsers() : async [UserTypes.UserRecord] {
    if (not UserLib.isAdmin(usersState, caller)) return [];
    UserLib.listUsers(usersState);
  };
};
