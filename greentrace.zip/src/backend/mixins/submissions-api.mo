import Common "../types/common";
import SubmissionTypes "../types/submissions";
import SubmissionLib "../lib/submissions";
import StatsLib "../lib/stats";
import UserLib "../lib/users";

mixin (
  submissionsState : SubmissionLib.State,
  usersState : UserLib.State,
  statsState : StatsLib.State,
) {
  public shared ({ caller }) func approveSubmission(
    submissionId : Common.SubmissionId,
    notes : ?Text,
  ) : async Bool {
    if (not UserLib.isAdmin(usersState, caller) and not UserLib.isManager(usersState, caller)) {
      return false;
    };
    switch (SubmissionLib.approveSubmission(submissionsState, caller, submissionId, notes)) {
      case null false;
      case (?updated) {
        StatsLib.recordApproval(statsState, updated);
        true;
      };
    };
  };

  public shared ({ caller }) func rejectSubmission(
    submissionId : Common.SubmissionId,
    notes : ?Text,
  ) : async Bool {
    if (not UserLib.isAdmin(usersState, caller) and not UserLib.isManager(usersState, caller)) {
      return false;
    };
    switch (SubmissionLib.rejectSubmission(submissionsState, caller, submissionId, notes)) {
      case null false;
      case (?updated) {
        StatsLib.recordRejection(statsState, updated);
        true;
      };
    };
  };

  public shared query ({ caller }) func getSubmissions(
    status : ?Common.SubmissionStatus,
    buildingId : ?Common.BuildingId,
    wardId : ?Common.WardId,
    limit : ?Nat,
  ) : async [SubmissionTypes.Submission] {
    let scopedBuildingId : ?Common.BuildingId = if (UserLib.isAdmin(usersState, caller)) {
      buildingId;
    } else {
      let scope = UserLib.getManagerScope(usersState, caller);
      switch (buildingId, scope.buildingId) {
        case (?req, ?mine) { if (req == mine) ?req else scope.buildingId };
        case (null, ?mine) ?mine;
        case (?req, null) ?req;
        case (null, null) null;
      };
    };
    SubmissionLib.getSubmissions(submissionsState, {
      status;
      buildingId = scopedBuildingId;
      wardId;
      limit;
    });
  };

  public shared query ({ caller }) func getVerificationQueue(
    buildingId : ?Common.BuildingId,
    wardId : ?Common.WardId,
  ) : async [SubmissionTypes.QueueItem] {
    if (UserLib.isAdmin(usersState, caller)) {
      return SubmissionLib.getVerificationQueue(submissionsState, buildingId, wardId);
    };
    let scope = UserLib.getManagerScope(usersState, caller);
    let effectiveBuildingId = switch (buildingId) {
      case (?b) ?b;
      case null scope.buildingId;
    };
    let effectiveWardId = switch (wardId) {
      case (?w) ?w;
      case null scope.wardId;
    };
    SubmissionLib.getVerificationQueue(submissionsState, effectiveBuildingId, effectiveWardId);
  };
};
