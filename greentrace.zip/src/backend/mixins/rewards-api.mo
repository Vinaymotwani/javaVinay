import Common "../types/common";
import RewardTypes "../types/rewards";
import RewardLib "../lib/rewards";
import UserLib "../lib/users";

mixin (
  rewardsState : RewardLib.State,
  usersState : UserLib.State,
) {
  public shared query ({ caller }) func listRewardCatalog() : async [RewardTypes.RewardItem] {
    RewardLib.listRewardCatalog(rewardsState);
  };

  public shared ({ caller }) func addRewardItem(
    input : RewardTypes.RewardInput,
  ) : async Common.RewardId {
    if (not UserLib.isAdmin(usersState, caller)) {
      return "error-unauthorized";
    };
    RewardLib.addRewardItem(rewardsState, caller, input);
  };

  public shared ({ caller }) func redeemReward(
    rewardId : Common.RewardId,
  ) : async Common.RequestId {
    RewardLib.redeemReward(rewardsState, caller, rewardId);
  };

  public shared query ({ caller }) func listRedemptionRequests(
    userId : ?Common.UserId,
  ) : async [RewardTypes.RedemptionRequest] {
    // Admin can query any userId; regular users only see their own
    let effectiveUserId : ?Common.UserId = if (UserLib.isAdmin(usersState, caller)) {
      userId;
    } else {
      ?caller;
    };
    RewardLib.listRedemptionRequests(rewardsState, effectiveUserId);
  };
};
