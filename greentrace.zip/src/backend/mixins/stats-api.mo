import Common "../types/common";
import StatsTypes "../types/stats";
import StatsLib "../lib/stats";
import UserLib "../lib/users";
import SubmissionLib "../lib/submissions";

mixin (
  statsState : StatsLib.State,
  usersState : UserLib.State,
  submissionsState : SubmissionLib.State,
) {
  public shared query ({ caller }) func getDashboardStats(
    buildingId : ?Common.BuildingId,
    wardId : ?Common.WardId,
  ) : async StatsTypes.DashboardStats {
    let effectiveBuildingId : ?Common.BuildingId = if (UserLib.isAdmin(usersState, caller)) {
      buildingId;
    } else {
      let scope = UserLib.getManagerScope(usersState, caller);
      switch (buildingId) {
        case (?b) ?b;
        case null scope.buildingId;
      };
    };
    let effectiveWardId : ?Common.WardId = if (UserLib.isAdmin(usersState, caller)) {
      wardId;
    } else {
      let scope = UserLib.getManagerScope(usersState, caller);
      switch (wardId) {
        case (?w) ?w;
        case null scope.wardId;
      };
    };
    StatsLib.getDashboardStats(statsState, submissionsState, effectiveBuildingId, effectiveWardId);
  };

  public shared query ({ caller }) func getScopeStats(
    scopeType : Common.ScopeType,
    scopeId : Text,
  ) : async [StatsTypes.DailyStats] {
    StatsLib.getScopeStats(statsState, scopeType, scopeId);
  };

  public shared query ({ caller }) func getLeaderboard(
    scopeType : Common.ScopeType,
    scopeId : ?Text,
    period : Common.Period,
    limit : Nat,
  ) : async [StatsTypes.LeaderboardEntry] {
    StatsLib.getLeaderboard(statsState, scopeType, scopeId, period, limit);
  };
};
