import Map "mo:core/Map";
import Time "mo:core/Time";
import Common "../types/common";
import UserTypes "../types/users";

module {
  public type State = {
    users : Map.Map<Common.UserId, UserTypes.UserRecord>;
  };

  public func isAdmin(
    state : State,
    caller : Common.UserId,
  ) : Bool {
    switch (state.users.get(caller)) {
      case (?(user)) { user.role == #admin };
      case null false;
    };
  };

  public func isManager(
    state : State,
    caller : Common.UserId,
  ) : Bool {
    switch (state.users.get(caller)) {
      case (?(user)) { user.role == #manager };
      case null false;
    };
  };

  public func getUser(
    state : State,
    id : Common.UserId,
  ) : ?UserTypes.UserRecord {
    state.users.get(id);
  };

  public func setUserRole(
    state : State,
    caller : Common.UserId,
    target : Common.UserId,
    role : Common.Role,
    buildingId : ?Common.BuildingId,
    wardId : ?Common.WardId,
  ) : () {
    if (not isAdmin(state, caller)) {
      return;
    };
    let existing = state.users.get(target);
    let createdAt : Common.Timestamp = switch (existing) {
      case (?u) u.createdAt;
      case null Time.now();
    };
    state.users.add(target, {
      id = target;
      role;
      buildingId;
      wardId;
      createdAt;
    });
  };

  public func getManagerScope(
    state : State,
    caller : Common.UserId,
  ) : { buildingId : ?Common.BuildingId; wardId : ?Common.WardId } {
    switch (state.users.get(caller)) {
      case (?(user)) { { buildingId = user.buildingId; wardId = user.wardId } };
      case null { { buildingId = null; wardId = null } };
    };
  };

  public func callerInScope(
    state : State,
    caller : Common.UserId,
    buildingId : ?Common.BuildingId,
    wardId : ?Common.WardId,
  ) : Bool {
    if (isAdmin(state, caller)) return true;
    let scope = getManagerScope(state, caller);
    let buildingMatch : Bool = switch (buildingId, scope.buildingId) {
      case (?req, ?mine) { req == mine };
      case (null, _) true;
      case (_, null) false;
    };
    let wardMatch : Bool = switch (wardId, scope.wardId) {
      case (?req, ?mine) { req == mine };
      case (null, _) true;
      case (_, null) false;
    };
    buildingMatch and wardMatch;
  };

  public func listUsers(state : State) : [UserTypes.UserRecord] {
    state.users.values()
      |> _.toArray();
  };
};
