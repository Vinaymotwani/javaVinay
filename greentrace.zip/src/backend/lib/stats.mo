import Map "mo:core/Map";
import Array "mo:core/Array";
import Iter "mo:core/Iter";
import Time "mo:core/Time";
import Int "mo:core/Int";
import Nat "mo:core/Nat";
import Common "../types/common";
import StatsTypes "../types/stats";
import SubmissionTypes "../types/submissions";

module {
  public type State = {
    stats : Map.Map<Text, StatsTypes.DailyStats>;
    userPoints : Map.Map<Common.UserId, Nat>;
    userStreaks : Map.Map<Common.UserId, Nat>;
    userApprovedCounts : Map.Map<Common.UserId, Nat>;
    userDisplayNames : Map.Map<Common.UserId, Text>;
    userBuildingIds : Map.Map<Common.UserId, Common.BuildingId>;
    userWardIds : Map.Map<Common.UserId, Common.WardId>;
  };

  // Returns ISO date string "YYYY-MM-DD" from nanosecond timestamp
  func dateFromNs(ns : Int) : Text {
    let seconds = Int.abs(ns) / 1_000_000_000;
    let days = seconds / 86400;
    // Compute year/month/day from Unix epoch (Jan 1 1970)
    var remaining = days;
    var year = 1970;
    label yearLoop loop {
      let daysInYear : Nat = if ((year % 4 == 0 and year % 100 != 0) or year % 400 == 0) 366 else 365;
      if (remaining < daysInYear) { break yearLoop };
      remaining -= daysInYear;
      year += 1;
    };
    let monthDays : [Nat] = if ((year % 4 == 0 and year % 100 != 0) or year % 400 == 0)
      [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    else
      [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    var month = 1;
    label monthLoop for (md in monthDays.values()) {
      if (remaining < md) { break monthLoop };
      remaining -= md;
      month += 1;
    };
    let day = remaining + 1;

    let pad = func(n : Nat) : Text {
      if (n < 10) "0" # n.toText() else n.toText()
    };
    year.toText() # "-" # pad(month) # "-" # pad(day);
  };

  func statsKey(scopeType : Common.ScopeType, scopeId : Text, date : Text) : Text {
    let st = switch (scopeType) {
      case (#global) "global";
      case (#ward) "ward";
      case (#building) "building";
    };
    st # "/" # scopeId # "/" # date;
  };

  func getOrCreateStats(
    state : State,
    scopeType : Common.ScopeType,
    scopeId : Text,
    date : Text,
  ) : StatsTypes.DailyStats {
    let key = statsKey(scopeType, scopeId, date);
    switch (state.stats.get(key)) {
      case (?s) s;
      case null {
        {
          date;
          scopeType;
          scopeId;
          totalSubmissions = 0;
          approved = 0;
          rejected = 0;
          pending = 0;
          points = 0;
        };
      };
    };
  };

  public func getDashboardStats(
    state : State,
    submissionsState : {
      submissions : Map.Map<Common.SubmissionId, SubmissionTypes.Submission>;
    },
    buildingId : ?Common.BuildingId,
    wardId : ?Common.WardId,
  ) : StatsTypes.DashboardStats {
    var total = 0;
    var approved = 0;
    var rejected = 0;
    var pending = 0;

    for ((_, sub) in submissionsState.submissions.entries()) {
      let buildingMatch = switch (buildingId) {
        case (?b) sub.buildingId == b;
        case null true;
      };
      let wardMatch = switch (wardId) {
        case (?w) sub.wardId == w;
        case null true;
      };
      if (buildingMatch and wardMatch) {
        total += 1;
        switch (sub.status) {
          case (#approved) { approved += 1 };
          case (#rejected) { rejected += 1 };
          case (#pending_review) { pending += 1 };
        };
      };
    };

    let denominator = approved + rejected;
    let complianceRate : Float = if (denominator == 0) 0.0
      else (approved.toFloat() / denominator.toFloat()) * 100.0;

    { totalSubmissions = total; approved; rejected; pending; complianceRate };
  };

  public func getScopeStats(
    state : State,
    scopeType : Common.ScopeType,
    scopeId : Text,
  ) : [StatsTypes.DailyStats] {
    let prefix = switch (scopeType) {
      case (#global) "global/" # scopeId # "/";
      case (#ward) "ward/" # scopeId # "/";
      case (#building) "building/" # scopeId # "/";
    };
    state.stats.entries()
      |> _.filter(func((k, _) : (Text, StatsTypes.DailyStats)) : Bool {
          k.startsWith(#text prefix);
        })
      |> _.map(func((_, v) : (Text, StatsTypes.DailyStats)) : StatsTypes.DailyStats { v })
      |> _.toArray();
  };

  public func getLeaderboard(
    state : State,
    scopeType : Common.ScopeType,
    scopeId : ?Text,
    period : Common.Period,
    limit : Nat,
  ) : [StatsTypes.LeaderboardEntry] {
    // Build entries from userPoints map, filtering by scope
    let entries : [StatsTypes.LeaderboardEntry] = state.userPoints.entries()
      |> _.filter(func((uid, _) : (Common.UserId, Nat)) : Bool {
          switch (scopeType) {
            case (#global) true;
            case (#building) {
              switch (scopeId) {
                case null true;
                case (?sid) {
                  switch (state.userBuildingIds.get(uid)) {
                    case (?bid) bid == sid;
                    case null false;
                  };
                };
              };
            };
            case (#ward) {
              switch (scopeId) {
                case null true;
                case (?sid) {
                  switch (state.userWardIds.get(uid)) {
                    case (?wid) wid == sid;
                    case null false;
                  };
                };
              };
            };
          };
        })
      |> _.map(func((uid, pts) : (Common.UserId, Nat)) : StatsTypes.LeaderboardEntry {
          let streak = switch (state.userStreaks.get(uid)) { case (?s) s; case null 0 };
          let approvedCount = switch (state.userApprovedCounts.get(uid)) { case (?c) c; case null 0 };
          let displayName = state.userDisplayNames.get(uid);
          let buildingId = state.userBuildingIds.get(uid);
          let wardId = state.userWardIds.get(uid);
          {
            rank = 0; // placeholder, set below
            userId = uid;
            displayName;
            buildingId;
            wardId;
            points = pts;
            streak;
            approvedCount;
          };
        })
      |> _.toArray();

    // Sort by points descending
    let sorted = entries.sort(func(a, b) {
      if (a.points > b.points) #less
      else if (a.points < b.points) #greater
      else #equal
    });

    // Assign ranks and apply limit
    let limited = if (sorted.size() > limit) sorted.sliceToArray(0, limit) else sorted;
    limited.mapEntries<StatsTypes.LeaderboardEntry, StatsTypes.LeaderboardEntry>(
      func(entry, idx) { { entry with rank = idx + 1 } }
    );
  };

  func updateDailyStats(
    state : State,
    submission : SubmissionTypes.Submission,
    isApproval : Bool,
  ) : () {
    let today = dateFromNs(Time.now());
    let pointsAwarded : Nat = if (isApproval) 10 else 0;

    // Update building-scoped stats
    let buildingKey = statsKey(#building, submission.buildingId, today);
    let buildingStats = getOrCreateStats(state, #building, submission.buildingId, today);
    state.stats.add(
      buildingKey,
      if (isApproval) {
        {
          buildingStats with
          approved = buildingStats.approved + 1;
          totalSubmissions = buildingStats.totalSubmissions + 1;
          points = buildingStats.points + pointsAwarded;
        };
      } else {
        {
          buildingStats with
          rejected = buildingStats.rejected + 1;
          totalSubmissions = buildingStats.totalSubmissions + 1;
        };
      },
    );

    // Update ward-scoped stats
    let wardKey = statsKey(#ward, submission.wardId, today);
    let wardStats = getOrCreateStats(state, #ward, submission.wardId, today);
    state.stats.add(
      wardKey,
      if (isApproval) {
        {
          wardStats with
          approved = wardStats.approved + 1;
          totalSubmissions = wardStats.totalSubmissions + 1;
          points = wardStats.points + pointsAwarded;
        };
      } else {
        {
          wardStats with
          rejected = wardStats.rejected + 1;
          totalSubmissions = wardStats.totalSubmissions + 1;
        };
      },
    );

    // Update global stats
    let globalKey = statsKey(#global, "global", today);
    let globalStats = getOrCreateStats(state, #global, "global", today);
    state.stats.add(
      globalKey,
      if (isApproval) {
        {
          globalStats with
          approved = globalStats.approved + 1;
          totalSubmissions = globalStats.totalSubmissions + 1;
          points = globalStats.points + pointsAwarded;
        };
      } else {
        {
          globalStats with
          rejected = globalStats.rejected + 1;
          totalSubmissions = globalStats.totalSubmissions + 1;
        };
      },
    );

    // Update user stats
    let uid = submission.submittedBy;
    if (isApproval) {
      let currentPoints = switch (state.userPoints.get(uid)) { case (?p) p; case null 0 };
      state.userPoints.add(uid, currentPoints + pointsAwarded);
      let currentApproved = switch (state.userApprovedCounts.get(uid)) { case (?c) c; case null 0 };
      state.userApprovedCounts.add(uid, currentApproved + 1);
      // Update scope tracking
      state.userBuildingIds.add(uid, submission.buildingId);
      state.userWardIds.add(uid, submission.wardId);
    };
  };

  public func recordApproval(
    state : State,
    submission : SubmissionTypes.Submission,
  ) : () {
    updateDailyStats(state, submission, true);
  };

  public func recordRejection(
    state : State,
    submission : SubmissionTypes.Submission,
  ) : () {
    updateDailyStats(state, submission, false);
  };
};
