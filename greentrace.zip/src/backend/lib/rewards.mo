import Map "mo:core/Map";
import Nat "mo:core/Nat";
import Time "mo:core/Time";
import Common "../types/common";
import RewardTypes "../types/rewards";

module {
  public type State = {
    rewardsCatalog : Map.Map<Common.RewardId, RewardTypes.RewardItem>;
    redemptionRequests : Map.Map<Common.RequestId, RewardTypes.RedemptionRequest>;
  };

  public func listRewardCatalog(state : State) : [RewardTypes.RewardItem] {
    state.rewardsCatalog.values()
      |> _.filter(func(r : RewardTypes.RewardItem) : Bool { r.active })
      |> _.toArray();
  };

  public func getReward(
    state : State,
    rewardId : Common.RewardId,
  ) : ?RewardTypes.RewardItem {
    state.rewardsCatalog.get(rewardId);
  };

  public func addRewardItem(
    state : State,
    caller : Common.UserId,
    input : RewardTypes.RewardInput,
  ) : Common.RewardId {
    let id = "reward-" # caller.toText() # "-" # (Time.now().toText());
    let item : RewardTypes.RewardItem = {
      id;
      name = input.name;
      description = input.description;
      pointsRequired = input.pointsRequired;
      stock = input.stock;
      active = true;
    };
    state.rewardsCatalog.add(id, item);
    id;
  };

  public func listRedemptionRequests(
    state : State,
    userId : ?Common.UserId,
  ) : [RewardTypes.RedemptionRequest] {
    state.redemptionRequests.values()
      |> _.filter(func(r : RewardTypes.RedemptionRequest) : Bool {
          switch (userId) {
            case (?uid) { r.userId == uid };
            case null true;
          };
        })
      |> _.toArray();
  };

  public func redeemReward(
    state : State,
    userId : Common.UserId,
    rewardId : Common.RewardId,
  ) : Common.RequestId {
    let reward = switch (state.rewardsCatalog.get(rewardId)) {
      case null { return "error-reward-not-found" };
      case (?r) r;
    };
    if (not reward.active or reward.stock == 0) {
      return "error-reward-unavailable";
    };
    // Decrement stock
    state.rewardsCatalog.add(rewardId, { reward with stock = Nat.sub(reward.stock, 1) });
    let requestId = "req-" # userId.toText() # "-" # (Time.now().toText());
    let request : RewardTypes.RedemptionRequest = {
      id = requestId;
      userId;
      rewardId;
      requestedAt = Time.now();
      status = "pending";
    };
    state.redemptionRequests.add(requestId, request);
    requestId;
  };
};
