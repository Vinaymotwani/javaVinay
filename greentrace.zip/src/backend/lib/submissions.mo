import Map "mo:core/Map";
import Time "mo:core/Time";
import Iter "mo:core/Iter";
import Common "../types/common";
import SubmissionTypes "../types/submissions";

module {
  public type State = {
    submissions : Map.Map<Common.SubmissionId, SubmissionTypes.Submission>;
    verificationQueue : Map.Map<Common.SubmissionId, SubmissionTypes.QueueItem>;
  };

  public func getSubmissions(
    state : State,
    filters : SubmissionTypes.SubmissionFilters,
  ) : [SubmissionTypes.Submission] {
    var results : [SubmissionTypes.Submission] = state.submissions.values()
      |> _.filter(func(s : SubmissionTypes.Submission) : Bool {
          let statusMatch = switch (filters.status) {
            case (?st) { s.status == st };
            case null true;
          };
          let buildingMatch = switch (filters.buildingId) {
            case (?b) { s.buildingId == b };
            case null true;
          };
          let wardMatch = switch (filters.wardId) {
            case (?w) { s.wardId == w };
            case null true;
          };
          statusMatch and buildingMatch and wardMatch;
        })
      |> _.toArray();

    switch (filters.limit) {
      case (?lim) {
        if (results.size() > lim) {
          results.sliceToArray(0, lim);
        } else results;
      };
      case null results;
    };
  };

  public func getVerificationQueue(
    state : State,
    buildingId : ?Common.BuildingId,
    wardId : ?Common.WardId,
  ) : [SubmissionTypes.QueueItem] {
    state.verificationQueue.values()
      |> _.filter(func(item : SubmissionTypes.QueueItem) : Bool {
          let buildingMatch = switch (buildingId) {
            case (?b) { item.submission.buildingId == b };
            case null true;
          };
          let wardMatch = switch (wardId) {
            case (?w) { item.submission.wardId == w };
            case null true;
          };
          buildingMatch and wardMatch;
        })
      |> _.toArray();
  };

  public func approveSubmission(
    state : State,
    caller : Common.UserId,
    submissionId : Common.SubmissionId,
    notes : ?Text,
  ) : ?SubmissionTypes.Submission {
    switch (state.submissions.get(submissionId)) {
      case null null;
      case (?sub) {
        let updated : SubmissionTypes.Submission = {
          sub with
          status = #approved;
          reviewedAt = ?Time.now();
          reviewedBy = ?caller;
          notes;
        };
        state.submissions.add(submissionId, updated);
        state.verificationQueue.remove(submissionId);
        ?updated;
      };
    };
  };

  public func rejectSubmission(
    state : State,
    caller : Common.UserId,
    submissionId : Common.SubmissionId,
    notes : ?Text,
  ) : ?SubmissionTypes.Submission {
    switch (state.submissions.get(submissionId)) {
      case null null;
      case (?sub) {
        let updated : SubmissionTypes.Submission = {
          sub with
          status = #rejected;
          reviewedAt = ?Time.now();
          reviewedBy = ?caller;
          notes;
        };
        state.submissions.add(submissionId, updated);
        state.verificationQueue.remove(submissionId);
        ?updated;
      };
    };
  };

  public func addSubmission(
    state : State,
    submission : SubmissionTypes.Submission,
  ) : () {
    state.submissions.add(submission.id, submission);
  };

  public func enqueue(
    state : State,
    item : SubmissionTypes.QueueItem,
  ) : () {
    state.verificationQueue.add(item.submissionId, item);
  };

  public func removeFromQueue(
    state : State,
    submissionId : Common.SubmissionId,
  ) : () {
    state.verificationQueue.remove(submissionId);
  };
};
