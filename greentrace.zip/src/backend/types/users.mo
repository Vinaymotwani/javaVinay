import Common "common";

module {
  public type UserRecord = {
    id : Common.UserId;
    role : Common.Role;
    buildingId : ?Common.BuildingId;
    wardId : ?Common.WardId;
    createdAt : Common.Timestamp;
  };
};
