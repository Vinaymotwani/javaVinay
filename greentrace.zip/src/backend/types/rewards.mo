import Common "common";

module {
  public type RewardItem = {
    id : Common.RewardId;
    name : Text;
    description : Text;
    pointsRequired : Nat;
    stock : Nat;
    active : Bool;
  };

  public type RewardInput = {
    name : Text;
    description : Text;
    pointsRequired : Nat;
    stock : Nat;
  };

  public type RedemptionRequest = {
    id : Common.RequestId;
    userId : Common.UserId;
    rewardId : Common.RewardId;
    requestedAt : Common.Timestamp;
    status : Text;
  };
};
