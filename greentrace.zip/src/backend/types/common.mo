module {
  public type UserId = Principal;
  public type Timestamp = Int;
  public type BuildingId = Text;
  public type WardId = Text;
  public type SubmissionId = Text;
  public type QueueId = Text;
  public type RewardId = Text;
  public type RequestId = Text;

  public type Role = {
    #admin;
    #manager;
  };

  public type SubmissionStatus = {
    #pending_review;
    #approved;
    #rejected;
  };

  public type ScopeType = {
    #global;
    #ward;
    #building;
  };

  public type Period = {
    #weekly;
    #monthly;
    #allTime;
  };

  public type ScopeFilter = {
    scopeType : ScopeType;
    scopeId : Text;
  };
};
