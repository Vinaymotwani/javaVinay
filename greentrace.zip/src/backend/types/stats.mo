import Common "common";

module {
  public type DailyStats = {
    date : Text;
    scopeType : Common.ScopeType;
    scopeId : Text;
    totalSubmissions : Nat;
    approved : Nat;
    rejected : Nat;
    pending : Nat;
    points : Nat;
  };

  public type DashboardStats = {
    totalSubmissions : Nat;
    approved : Nat;
    rejected : Nat;
    pending : Nat;
    complianceRate : Float;
  };

  public type LeaderboardEntry = {
    rank : Nat;
    userId : Common.UserId;
    displayName : ?Text;
    buildingId : ?Common.BuildingId;
    wardId : ?Common.WardId;
    points : Nat;
    streak : Nat;
    approvedCount : Nat;
  };
};
