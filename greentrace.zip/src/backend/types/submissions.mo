import Common "common";

module {
  public type Submission = {
    id : Common.SubmissionId;
    submittedBy : Common.UserId;
    buildingId : Common.BuildingId;
    wardId : Common.WardId;
    wasteType : Text;
    imageUrl : ?Text;
    status : Common.SubmissionStatus;
    submittedAt : Common.Timestamp;
    reviewedAt : ?Common.Timestamp;
    reviewedBy : ?Common.UserId;
    notes : ?Text;
  };

  public type QueueItem = {
    submissionId : Common.SubmissionId;
    submission : Submission;
    flagged : Bool;
    tags : [Text];
  };

  public type SubmissionFilters = {
    status : ?Common.SubmissionStatus;
    buildingId : ?Common.BuildingId;
    wardId : ?Common.WardId;
    limit : ?Nat;
  };
};
