import Map "mo:core/Map";
import Common "types/common";
import UserTypes "types/users";
import SubmissionTypes "types/submissions";
import RewardTypes "types/rewards";
import StatsTypes "types/stats";
import UserLib "lib/users";
import SubmissionLib "lib/submissions";
import RewardLib "lib/rewards";
import StatsLib "lib/stats";
import UsersMixin "mixins/users-api";
import SubmissionsMixin "mixins/submissions-api";
import RewardsMixin "mixins/rewards-api";
import StatsMixin "mixins/stats-api";
import Migration "migration";

(with migration = Migration.run)
actor {
  // Users state
  let usersState : UserLib.State = {
    users = Map.empty<Common.UserId, UserTypes.UserRecord>();
  };

  // Submissions state
  let submissionsState : SubmissionLib.State = {
    submissions = Map.empty<Common.SubmissionId, SubmissionTypes.Submission>();
    verificationQueue = Map.empty<Common.SubmissionId, SubmissionTypes.QueueItem>();
  };

  // Rewards state
  let rewardsState : RewardLib.State = {
    rewardsCatalog = Map.empty<Common.RewardId, RewardTypes.RewardItem>();
    redemptionRequests = Map.empty<Common.RequestId, RewardTypes.RedemptionRequest>();
  };

  // Stats state
  let statsState : StatsLib.State = {
    stats = Map.empty<Text, StatsTypes.DailyStats>();
    userPoints = Map.empty<Common.UserId, Nat>();
    userStreaks = Map.empty<Common.UserId, Nat>();
    userApprovedCounts = Map.empty<Common.UserId, Nat>();
    userDisplayNames = Map.empty<Common.UserId, Text>();
    userBuildingIds = Map.empty<Common.UserId, Common.BuildingId>();
    userWardIds = Map.empty<Common.UserId, Common.WardId>();
  };

  include UsersMixin(usersState);
  include SubmissionsMixin(submissionsState, usersState, statsState);
  include RewardsMixin(rewardsState, usersState);
  include StatsMixin(statsState, usersState, submissionsState);
};
