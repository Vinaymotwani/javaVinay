import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import {
  BarChart3,
  Building2,
  CheckCircle2,
  LandPlot,
  Loader2,
  ShieldAlert,
  XCircle,
} from "lucide-react";
import { useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { EmptyState } from "../components/common/EmptyState";
import { ErrorState } from "../components/common/ErrorState";
import { useRole } from "../hooks/useRole";
import { useBackendActor } from "../services/backend";
import { fetchScopeStats } from "../services/statsService";

// ─── helpers ────────────────────────────────────────────────────────────────

function complianceRate(approved, rejected) {
  const total = Number(approved) + Number(rejected);
  if (total === 0) return "—";
  return `${((Number(approved) / total) * 100).toFixed(1)}%`;
}

function sumStats(rows) {
  return rows.reduce(
    (acc, d) => ({
      total: acc.total + Number(d.totalSubmissions),
      approved: acc.approved + Number(d.approved),
      rejected: acc.rejected + Number(d.rejected),
      pending: acc.pending + Number(d.pending),
    }),
    { total: 0, approved: 0, rejected: 0, pending: 0 },
  );
}

// ─── sub-components ─────────────────────────────────────────────────────────

function StatCard({ icon, label, value, color }) {
  return (
    <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 shadow-card">
      <div
        className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg"
        style={{ background: `${color}18` }}
      >
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </p>
        <p className="text-xl font-bold text-foreground">{value}</p>
      </div>
    </div>
  );
}

function DailyTable({ rows }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-border bg-card shadow-card">
      <table className="w-full text-sm" data-ocid="reports-daily-table">
        <thead>
          <tr className="border-b border-border bg-muted/40">
            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Date
            </th>
            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Total
            </th>
            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Approved
            </th>
            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Rejected
            </th>
            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Pending
            </th>
            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Compliance
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr
              key={row.date}
              className={i % 2 === 0 ? "bg-background" : "bg-muted/20"}
              data-ocid={`reports-row-${row.date}`}
            >
              <td className="px-4 py-3 font-mono text-xs text-foreground">
                {row.date}
              </td>
              <td className="px-4 py-3 text-right font-medium text-foreground">
                {Number(row.totalSubmissions)}
              </td>
              <td className="px-4 py-3 text-right font-medium text-[#22c55e]">
                {Number(row.approved)}
              </td>
              <td className="px-4 py-3 text-right font-medium text-[#ef4444]">
                {Number(row.rejected)}
              </td>
              <td className="px-4 py-3 text-right text-muted-foreground">
                {Number(row.pending)}
              </td>
              <td className="px-4 py-3 text-right">
                <Badge
                  variant="outline"
                  className="font-mono text-xs"
                  style={{
                    color:
                      Number(row.approved) + Number(row.rejected) === 0
                        ? undefined
                        : Number(row.approved) /
                              (Number(row.approved) + Number(row.rejected)) >=
                            0.8
                          ? "#22c55e"
                          : "#ef4444",
                  }}
                >
                  {complianceRate(row.approved, row.rejected)}
                </Badge>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── main component ──────────────────────────────────────────────────────────

export function ReportsPage() {
  const { actor, isFetching } = useBackendActor();
  const { isAdmin, isManager, scope } = useRole();

  const managerScopeType = scope?.buildingId ? "building" : "ward";
  const managerScopeId = scope?.buildingId ?? scope?.wardId ?? "";

  const [scopeType, setScopeType] = useState(
    isAdmin ? "building" : managerScopeType,
  );
  const [scopeId, setScopeId] = useState(isAdmin ? "" : managerScopeId);
  const [queryParams, setQueryParams] = useState(null); // null = not yet loaded

  // Determine if manager is trying to access a forbidden scope
  const isForbidden =
    isManager &&
    queryParams !== null &&
    (queryParams.scopeType !== managerScopeType ||
      queryParams.scopeId !== managerScopeId);

  const {
    data: dailyStats = [],
    isLoading,
    isError,
    refetch,
  } = useQuery({
    queryKey: ["scopeStats", queryParams?.scopeType, queryParams?.scopeId],
    queryFn: () =>
      fetchScopeStats(actor, queryParams.scopeType, queryParams.scopeId),
    enabled:
      !!actor &&
      !isFetching &&
      queryParams !== null &&
      !!queryParams.scopeId &&
      !isForbidden,
  });

  function handleLoad() {
    if (!scopeId.trim()) return;

    // Enforce manager scope
    if (isManager) {
      setQueryParams({ scopeType: managerScopeType, scopeId: managerScopeId });
    } else {
      setQueryParams({ scopeType, scopeId: scopeId.trim() });
    }
  }

  const chartData = dailyStats.map((d) => ({
    date: d.date,
    Approved: Number(d.approved),
    Rejected: Number(d.rejected),
  }));

  const summary = sumStats(dailyStats);

  const loaded = queryParams !== null && !isLoading && !isError && !isForbidden;

  return (
    <div className="flex-1 p-6 lg:p-8">
      {/* Header */}
      <div className="mb-6">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Analytics
        </p>
        <h1 className="font-display text-2xl font-bold text-foreground">
          Reports
        </h1>
      </div>

      {/* Scope selector */}
      <div
        className="mb-6 flex flex-wrap items-end gap-3"
        data-ocid="reports-filters"
      >
        {/* Scope type toggle */}
        <div className="flex overflow-hidden rounded-lg border border-border bg-muted/40">
          <button
            type="button"
            onClick={() => setScopeType("building")}
            disabled={isManager}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium transition-colors ${
              scopeType === "building"
                ? "bg-card text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
            data-ocid="reports-scope-building"
          >
            <Building2 size={14} />
            By Building
          </button>
          <button
            type="button"
            onClick={() => setScopeType("ward")}
            disabled={isManager}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium transition-colors ${
              scopeType === "ward"
                ? "bg-card text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
            data-ocid="reports-scope-ward"
          >
            <LandPlot size={14} />
            By Ward
          </button>
        </div>

        {/* Scope ID input */}
        <input
          className="flex h-9 w-44 rounded-md border border-input bg-background px-3 py-1 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:opacity-50"
          placeholder={scopeType === "building" ? "Building ID" : "Ward ID"}
          value={scopeId}
          onChange={(e) => setScopeId(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleLoad()}
          disabled={isManager}
          data-ocid="reports-scope-id"
        />

        {/* Load button */}
        <Button
          onClick={handleLoad}
          disabled={!scopeId.trim() || isLoading || !actor}
          data-ocid="reports-load-btn"
        >
          {isLoading ? (
            <>
              <Loader2 size={14} className="mr-1.5 animate-spin" />
              Loading…
            </>
          ) : (
            <>
              <BarChart3 size={14} className="mr-1.5" />
              Load Report
            </>
          )}
        </Button>
      </div>

      {/* Manager restriction warning */}
      {isForbidden && (
        <div
          className="mb-6 flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/8 p-4"
          data-ocid="reports-forbidden"
        >
          <ShieldAlert
            size={18}
            className="mt-0.5 flex-shrink-0 text-destructive"
          />
          <div>
            <p className="text-sm font-semibold text-destructive">
              Access restricted
            </p>
            <p className="text-sm text-muted-foreground">
              As a manager, you can only view stats for your assigned scope:{" "}
              <span className="font-medium text-foreground">
                {managerScopeType} / {managerScopeId}
              </span>
              .
            </p>
          </div>
        </div>
      )}

      {/* States */}
      {isError ? (
        <ErrorState
          title="Failed to load stats"
          description="Could not retrieve daily statistics. Check the scope ID and try again."
          onRetry={refetch}
          data-ocid="reports-error"
        />
      ) : queryParams === null ? (
        <EmptyState
          icon={<BarChart3 size={28} className="text-muted-foreground" />}
          title="Select a scope to begin"
          description="Choose building or ward, enter an ID, then click Load Report to view compliance analytics."
          data-ocid="reports-empty-initial"
        />
      ) : isLoading ? (
        <div className="space-y-4" data-ocid="reports-loading">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {["total", "approved", "rejected", "compliance"].map((k) => (
              <Skeleton key={k} className="h-[72px] rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-80 w-full rounded-xl" />
          <Skeleton className="h-64 w-full rounded-xl" />
        </div>
      ) : dailyStats.length === 0 ? (
        <EmptyState
          icon={<BarChart3 size={28} className="text-muted-foreground" />}
          title="No stats data for this scope and period"
          description="No daily stats found. Data will appear once submissions are recorded for this scope."
          data-ocid="reports-empty"
        />
      ) : loaded ? (
        <div className="space-y-6" data-ocid="reports-content">
          {/* Summary cards */}
          <div
            className="grid grid-cols-2 gap-4 sm:grid-cols-4"
            data-ocid="reports-summary"
          >
            <StatCard
              icon={<BarChart3 size={18} style={{ color: "#6366f1" }} />}
              label="Total"
              value={summary.total.toLocaleString()}
              color="#6366f1"
            />
            <StatCard
              icon={<CheckCircle2 size={18} style={{ color: "#22c55e" }} />}
              label="Approved"
              value={summary.approved.toLocaleString()}
              color="#22c55e"
            />
            <StatCard
              icon={<XCircle size={18} style={{ color: "#ef4444" }} />}
              label="Rejected"
              value={summary.rejected.toLocaleString()}
              color="#ef4444"
            />
            <StatCard
              icon={<BarChart3 size={18} style={{ color: "#f59e0b" }} />}
              label="Compliance Rate"
              value={complianceRate(summary.approved, summary.rejected)}
              color="#f59e0b"
            />
          </div>

          {/* Bar chart */}
          <div
            className="rounded-xl border border-border bg-card p-6 shadow-card"
            data-ocid="reports-chart"
          >
            <h2 className="mb-1 font-display text-base font-semibold text-foreground">
              Approved vs Rejected Over Time
            </h2>
            <p className="mb-5 text-xs text-muted-foreground">
              {scopeType === "building" ? "Building" : "Ward"} /{" "}
              {queryParams?.scopeId}
            </p>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={chartData}
                margin={{ top: 4, right: 16, left: 0, bottom: 0 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#e2e8f0"
                  vertical={false}
                />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 11, fill: "#94a3b8" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: "#94a3b8" }}
                  axisLine={false}
                  tickLine={false}
                  allowDecimals={false}
                />
                <Tooltip
                  cursor={{ fill: "#f1f5f9" }}
                  contentStyle={{
                    backgroundColor: "#ffffff",
                    border: "1px solid #e2e8f0",
                    borderRadius: "8px",
                    fontSize: 12,
                    color: "#0f172a",
                  }}
                />
                <Legend
                  iconType="square"
                  iconSize={10}
                  wrapperStyle={{ fontSize: 12, paddingTop: "12px" }}
                />
                <Bar dataKey="Approved" fill="#22c55e" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Rejected" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Daily breakdown table */}
          <div data-ocid="reports-table-section">
            <h2 className="mb-3 font-display text-base font-semibold text-foreground">
              Daily Breakdown
            </h2>
            <DailyTable rows={dailyStats} />
          </div>
        </div>
      ) : null}
    </div>
  );
}
