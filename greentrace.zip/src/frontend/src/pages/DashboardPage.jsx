import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import {
  CheckCircle2,
  Clock,
  FileStack,
  RefreshCw,
  TrendingUp,
  XCircle,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { EmptyState } from "../components/common/EmptyState";
import { ErrorState } from "../components/common/ErrorState";
import { ROLE_COLORS, ROLE_LABELS } from "../constants/roles";
import { useAuth } from "../hooks/useAuth";
import { useRole } from "../hooks/useRole";
import { useBackendActor } from "../services/backend";
import { fetchDashboardStats } from "../services/statsService";

// Hex literals — Recharts does NOT evaluate CSS custom properties
const HEX = {
  approved: "#22c55e",
  rejected: "#ef4444",
  pending: "#f97316",
  blue: "#3b82f6",
  gridLine: "#e5e7eb",
  axisTick: "#6b7280",
  tooltipCursor: "#f3f4f6",
};

const STAT_CONFIGS = [
  {
    key: "totalSubmissions",
    label: "Total Submissions",
    Icon: FileStack,
    valueColor: "text-foreground",
    iconBg: "bg-muted",
    iconColor: "text-muted-foreground",
    format: (v) => Number(v ?? 0).toLocaleString(),
    ocid: "stat-total",
  },
  {
    key: "approved",
    label: "Approved",
    Icon: CheckCircle2,
    valueColor: "text-[#16a34a]",
    iconBg: "bg-[#dcfce7]",
    iconColor: "text-[#16a34a]",
    format: (v) => Number(v ?? 0).toLocaleString(),
    ocid: "stat-approved",
  },
  {
    key: "rejected",
    label: "Rejected",
    Icon: XCircle,
    valueColor: "text-[#dc2626]",
    iconBg: "bg-[#fee2e2]",
    iconColor: "text-[#dc2626]",
    format: (v) => Number(v ?? 0).toLocaleString(),
    ocid: "stat-rejected",
  },
  {
    key: "pending",
    label: "Pending Review",
    Icon: Clock,
    valueColor: "text-[#ea580c]",
    iconBg: "bg-[#ffedd5]",
    iconColor: "text-[#ea580c]",
    format: (v) => Number(v ?? 0).toLocaleString(),
    ocid: "stat-pending",
  },
  {
    key: "complianceRate",
    label: "Compliance Rate",
    Icon: TrendingUp,
    valueColor: "text-[#2563eb]",
    iconBg: "bg-[#dbeafe]",
    iconColor: "text-[#2563eb]",
    format: (v) => {
      const raw = typeof v === "object" && v !== null ? Object.values(v)[0] : v;
      return `${Number(raw ?? 0).toFixed(1)}%`;
    },
    ocid: "stat-compliance",
  },
];

function StatCardSkeleton() {
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-card">
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-2">
          <Skeleton className="h-4 w-28" />
          <Skeleton className="h-8 w-20" />
        </div>
        <Skeleton className="h-10 w-10 rounded-lg shrink-0" />
      </div>
    </div>
  );
}

function StatCard({ label, value, Icon, valueColor, iconBg, iconColor, ocid }) {
  return (
    <div
      className="rounded-xl border border-border bg-card p-5 shadow-card transition-smooth hover:shadow-elevated"
      data-ocid={ocid}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-medium text-muted-foreground truncate">
            {label}
          </p>
          <p
            className={`mt-1.5 text-3xl font-bold font-display tracking-tight ${valueColor}`}
          >
            {value}
          </p>
        </div>
        <div
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${iconBg}`}
        >
          <Icon size={20} className={iconColor} aria-hidden="true" />
        </div>
      </div>
    </div>
  );
}

function buildBarData(stats) {
  if (!stats) return [];
  return [
    {
      name: "Approved",
      value: Number(stats.approved ?? 0),
      color: HEX.approved,
    },
    {
      name: "Rejected",
      value: Number(stats.rejected ?? 0),
      color: HEX.rejected,
    },
    { name: "Pending", value: Number(stats.pending ?? 0), color: HEX.pending },
  ];
}

function ChartTooltip({ active, payload }) {
  if (!active || !payload?.length) return null;
  const item = payload[0];
  return (
    <div className="rounded-lg border border-border bg-card px-3 py-2 shadow-elevated text-sm">
      <p className="font-semibold text-foreground">{item.payload.name}</p>
      <p className="text-muted-foreground">{item.value.toLocaleString()}</p>
    </div>
  );
}

export function DashboardPage() {
  const { isAuthenticated } = useAuth();
  const {
    role,
    isAdmin,
    isManager,
    buildingId,
    wardId,
    isLoading: roleLoading,
  } = useRole();
  const { actor, isFetching } = useBackendActor();

  const scope = isManager
    ? { buildingId: buildingId ?? null, wardId: wardId ?? null }
    : null;

  const {
    data: stats,
    isLoading: statsLoading,
    isError,
    error,
    refetch,
    dataUpdatedAt,
  } = useQuery({
    queryKey: ["dashboardStats", isAdmin ? "global" : scope],
    queryFn: () => fetchDashboardStats(actor, scope),
    enabled: isAuthenticated && !!actor && !isFetching && !roleLoading,
    refetchInterval: 5000,
    staleTime: 4000,
  });

  const isLoading = statsLoading || roleLoading || isFetching;
  const barData = buildBarData(stats);
  const hasData = stats && Number(stats.totalSubmissions ?? 0) > 0;
  const roleLabel = ROLE_LABELS[role] ?? "User";
  const roleBadgeCls = ROLE_COLORS[role] ?? "bg-muted text-muted-foreground";

  const lastUpdated = dataUpdatedAt
    ? new Date(dataUpdatedAt).toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      })
    : null;

  const complianceFormatted = stats
    ? STAT_CONFIGS.find((c) => c.key === "complianceRate")?.format(
        stats.complianceRate,
      )
    : null;

  return (
    <div className="space-y-8 p-6 pb-12" data-ocid="dashboard-page">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold font-display text-foreground tracking-tight">
            Dashboard
          </h1>
          <div className="mt-1.5 flex flex-wrap items-center gap-2">
            <Badge className={roleBadgeCls} data-ocid="role-badge">
              {roleLabel}
            </Badge>
            {isManager && (buildingId || wardId) && (
              <span className="text-xs text-muted-foreground">
                Scope:{" "}
                {buildingId ? `Building ${buildingId}` : `Ward ${wardId}`}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3">
          {lastUpdated && (
            <span className="hidden text-xs text-muted-foreground sm:inline">
              Updated {lastUpdated}
            </span>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetch()}
            disabled={isLoading}
            data-ocid="dashboard-refresh-btn"
            className="gap-1.5"
          >
            <RefreshCw
              size={14}
              className={isLoading ? "animate-spin" : ""}
              aria-hidden="true"
            />
            Refresh
          </Button>
        </div>
      </div>

      {/* Stat Cards */}
      {isLoading ? (
        <div
          className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5"
          data-ocid="stats-skeleton"
        >
          {STAT_CONFIGS.map((c) => (
            <StatCardSkeleton key={c.key} />
          ))}
        </div>
      ) : isError ? (
        <ErrorState
          title="Failed to load stats"
          description={
            error?.message ??
            "Could not fetch dashboard statistics. Please try again."
          }
          onRetry={refetch}
          data-ocid="stats-error"
        />
      ) : (
        <div
          className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5"
          data-ocid="stats-grid"
        >
          {STAT_CONFIGS.map(
            ({
              key,
              label,
              Icon,
              valueColor,
              iconBg,
              iconColor,
              format,
              ocid,
            }) => (
              <StatCard
                key={key}
                label={label}
                value={format(stats?.[key])}
                Icon={Icon}
                valueColor={valueColor}
                iconBg={iconBg}
                iconColor={iconColor}
                ocid={ocid}
              />
            ),
          )}
        </div>
      )}

      {/* Submission Breakdown Chart */}
      {!isLoading && !isError && (
        <div
          className="rounded-xl border border-border bg-card p-6 shadow-card"
          data-ocid="trend-chart"
        >
          <div className="mb-5">
            <h2 className="text-base font-semibold font-display text-foreground">
              Submission Breakdown
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              Distribution of submission statuses across the system
            </p>
          </div>

          {!hasData ? (
            <EmptyState
              title="No submissions yet"
              description="Submission data will appear here once residents start reporting waste segregation."
              data-ocid="trend-empty"
            />
          ) : (
            <div className="h-52" aria-label="Submission breakdown bar chart">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={barData}
                  margin={{ top: 4, right: 8, left: 0, bottom: 0 }}
                  barCategoryGap="40%"
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke={HEX.gridLine}
                    vertical={false}
                  />
                  <XAxis
                    dataKey="name"
                    tick={{ fill: HEX.axisTick, fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: HEX.axisTick, fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                    allowDecimals={false}
                  />
                  <Tooltip
                    content={<ChartTooltip />}
                    cursor={{ fill: HEX.tooltipCursor }}
                  />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                    {barData.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}

      {/* Compliance Callout (Admin only) */}
      {!isLoading && !isError && hasData && isAdmin && (
        <div
          className="flex items-center gap-4 rounded-xl border border-[#bfdbfe] bg-[#eff6ff] px-5 py-4"
          data-ocid="compliance-callout"
        >
          <TrendingUp
            size={22}
            className="shrink-0 text-[#2563eb]"
            aria-hidden="true"
          />
          <div className="min-w-0">
            <p className="text-sm font-semibold text-[#1e40af]">
              System-wide compliance rate:{" "}
              <span className="text-[#2563eb]">{complianceFormatted}</span>
            </p>
            <p className="mt-0.5 text-xs text-[#3b82f6]">
              Based on {Number(stats?.approved ?? 0).toLocaleString()} approved
              out of{" "}
              {(
                Number(stats?.approved ?? 0) + Number(stats?.rejected ?? 0)
              ).toLocaleString()}{" "}
              reviewed submissions.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
