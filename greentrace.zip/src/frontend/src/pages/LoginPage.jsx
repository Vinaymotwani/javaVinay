import { Button } from "@/components/ui/button";
import { Navigate } from "@tanstack/react-router";
import { BarChart3, CheckCircle, Leaf, Loader2, Shield } from "lucide-react";
import { useAuth } from "../hooks/useAuth";
import { loginWithII } from "../services/authService";

const FEATURES = [
  {
    icon: CheckCircle,
    title: "Verification Queue",
    description:
      "Review and approve waste segregation submissions in real-time",
  },
  {
    icon: Shield,
    title: "Role-Based Access",
    description:
      "Admins see everything; managers work within their assigned scope",
  },
  {
    icon: BarChart3,
    title: "Compliance Analytics",
    description: "Track compliance rates, trends, and leaderboards by area",
  },
];

export function LoginPage() {
  const { isAuthenticated, loading, login, loginStatus } = useAuth();

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="animate-spin text-primary" size={36} />
      </div>
    );
  }

  if (isAuthenticated) {
    return <Navigate to="/dashboard" />;
  }

  const isLoggingIn = loginStatus === "logging-in";

  return (
    <div className="flex min-h-screen bg-background">
      {/* Left panel — dark sidebar */}
      <div className="hidden w-[420px] flex-shrink-0 flex-col justify-between bg-[oklch(0.14_0_0)] p-10 lg:flex">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
            <Leaf size={20} className="text-primary-foreground" />
          </div>
          <div>
            <p className="font-display text-lg font-semibold text-white">
              GreenTrace
            </p>
            <p className="text-xs text-white/50">Municipal Bureau Platform</p>
          </div>
        </div>

        <div className="space-y-8">
          <div>
            <h1 className="font-display text-3xl font-bold leading-tight text-white">
              Waste Segregation
              <br />
              <span className="text-primary">Monitoring Portal</span>
            </h1>
            <p className="mt-3 text-sm leading-relaxed text-white/60">
              Manage compliance across buildings and wards, verify submissions,
              and track municipal performance in one place.
            </p>
          </div>

          <div className="space-y-5">
            {FEATURES.map((f) => (
              <div key={f.title} className="flex items-start gap-3">
                <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/15">
                  <f.icon size={16} className="text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">{f.title}</p>
                  <p className="text-xs leading-relaxed text-white/50">
                    {f.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <p className="text-xs text-white/30">
          © {new Date().getFullYear()} GreenTrace. Built with{" "}
          <a
            href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(typeof window !== "undefined" ? window.location.hostname : "")}`}
            target="_blank"
            rel="noreferrer"
            className="text-primary/60 hover:text-primary transition-colors"
          >
            caffeine.ai
          </a>
        </p>
      </div>

      {/* Right panel — login form */}
      <div className="flex flex-1 items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm">
          {/* Mobile logo */}
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary">
              <Leaf size={18} className="text-primary-foreground" />
            </div>
            <p className="font-display text-xl font-semibold text-foreground">
              GreenTrace
            </p>
          </div>

          <div className="mb-8">
            <h2 className="font-display text-2xl font-bold text-foreground">
              Welcome back
            </h2>
            <p className="mt-1.5 text-sm text-muted-foreground">
              Sign in with Internet Identity to access your dashboard.
            </p>
          </div>

          <Button
            size="lg"
            className="w-full gap-2 font-medium"
            onClick={() => loginWithII(login)}
            disabled={isLoggingIn}
            data-ocid="login-btn"
          >
            {isLoggingIn ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                Connecting…
              </>
            ) : (
              <>
                <Shield size={16} />
                Sign in with Internet Identity
              </>
            )}
          </Button>

          <p className="mt-4 text-center text-xs text-muted-foreground">
            One-click secure login — no passwords required.
          </p>
        </div>
      </div>
    </div>
  );
}
