import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  CheckCircle,
  MapPin,
  RefreshCw,
  Tag,
  XCircle,
} from "lucide-react";
import { useState } from "react";
import { EmptyState } from "../components/common/EmptyState";
import { ErrorState } from "../components/common/ErrorState";
import { useRole } from "../hooks/useRole";
import { useBackendActor } from "../services/backend";
import {
  approveSubmission,
  fetchVerificationQueue,
  rejectSubmission,
} from "../services/queueService";
import { formatTimestampRelative } from "../utils/dateUtils";
import { toast } from "../utils/toast";

// ─── Skeleton ────────────────────────────────────────────────────────────────

function QueueCardSkeleton() {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex gap-4">
        <Skeleton className="h-24 w-24 shrink-0 rounded-lg" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-3 w-48" />
          <Skeleton className="h-3 w-24" />
          <div className="flex gap-2 pt-1">
            <Skeleton className="h-6 w-16 rounded-full" />
            <Skeleton className="h-6 w-16 rounded-full" />
          </div>
        </div>
        <div className="flex shrink-0 flex-col gap-2">
          <Skeleton className="h-9 w-28 rounded-lg" />
          <Skeleton className="h-9 w-28 rounded-lg" />
        </div>
      </div>
    </div>
  );
}

// ─── Queue Card ───────────────────────────────────────────────────────────────

function QueueCard({ item, onApprove, onReject, pendingAction }) {
  const { submission, submissionId, flagged, tags } = item;
  const imageUrl = submission?.imageUrl ?? null;
  const isActing = pendingAction === submissionId;

  return (
    <div
      className="rounded-xl border border-border bg-card p-5 shadow-card transition-smooth hover:shadow-elevated"
      data-ocid="queue-item"
    >
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
        {/* Photo preview */}
        <div className="relative h-24 w-24 shrink-0 overflow-hidden rounded-lg bg-muted">
          {imageUrl ? (
            <img
              src={imageUrl}
              alt="Waste segregation submission"
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-muted-foreground">
              <Tag size={24} />
            </div>
          )}
          {flagged && (
            <span
              className="absolute right-1 top-1 h-2.5 w-2.5 rounded-full bg-accent ring-2 ring-card"
              aria-label="Flagged"
            />
          )}
        </div>

        {/* Details */}
        <div className="min-w-0 flex-1">
          <div className="mb-1.5 flex flex-wrap items-center gap-2">
            <span className="font-mono text-xs font-semibold text-foreground">
              #{submissionId?.slice(0, 8)}
            </span>
            <span className="text-xs text-muted-foreground">
              {formatTimestampRelative(submission?.submittedAt)}
            </span>
            {flagged && (
              <Badge
                variant="outline"
                className="gap-1 border-accent/40 text-accent text-xs"
              >
                <AlertTriangle size={10} />
                Flagged
              </Badge>
            )}
          </div>

          {/* Waste type */}
          {submission?.wasteType && (
            <p className="mb-1.5 text-sm font-medium text-foreground capitalize">
              {submission.wasteType.replace(/_/g, " ")}
            </p>
          )}

          {/* Tags */}
          {tags?.length > 0 && (
            <div className="mb-2 flex flex-wrap gap-1.5">
              {tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
          )}

          {/* Location */}
          {(submission?.buildingId || submission?.wardId) && (
            <p className="flex items-center gap-1 text-xs text-muted-foreground">
              <MapPin size={11} />
              {submission.buildingId
                ? `Building ${submission.buildingId}`
                : `Ward ${submission.wardId}`}
            </p>
          )}
        </div>

        {/* Actions */}
        <div className="flex shrink-0 flex-row gap-2 sm:flex-col">
          <Button
            size="sm"
            className="gap-1.5 bg-primary hover:bg-primary/90"
            onClick={() => onApprove(item)}
            disabled={isActing}
            aria-label={`Approve submission ${submissionId?.slice(0, 8)}`}
            data-ocid="approve-btn"
          >
            <CheckCircle size={14} />
            {isActing ? "Approving…" : "Approve"}
          </Button>
          <Button
            size="sm"
            variant="destructive"
            className="gap-1.5"
            onClick={() => onReject(item)}
            disabled={isActing}
            aria-label={`Reject submission ${submissionId?.slice(0, 8)}`}
            data-ocid="reject-btn"
          >
            <XCircle size={14} />
            {isActing ? "Rejecting…" : "Reject"}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─── Queue Page ───────────────────────────────────────────────────────────────

export function QueuePage() {
  const { actor, isFetching } = useBackendActor();
  const { isAdmin, isManager, scope, canActOnScope } = useRole();
  const queryClient = useQueryClient();

  // Track optimistic removals by submissionId
  const [removedIds, setRemovedIds] = useState(new Set());
  // Track which submissionId is currently being acted on
  const [pendingAction, setPendingAction] = useState(null);

  const {
    data: rawQueue = [],
    isLoading,
    isError,
    refetch,
    isFetching: isRefetching,
  } = useQuery({
    queryKey: ["verificationQueue", scope.buildingId, scope.wardId, isAdmin],
    queryFn: () =>
      fetchVerificationQueue(actor, {
        buildingId: scope.buildingId,
        wardId: scope.wardId,
      }),
    enabled: !!actor && !isFetching && (isAdmin || isManager),
    refetchInterval: 5000,
  });

  // Apply optimistic removals
  const queue = rawQueue.filter((item) => !removedIds.has(item.submissionId));

  const approveMutation = useMutation({
    mutationFn: ({ submissionId }) => approveSubmission(actor, submissionId),
    onMutate: ({ submissionId }) => {
      setPendingAction(submissionId);
      // Optimistic: remove from display
      setRemovedIds((prev) => new Set([...prev, submissionId]));
    },
    onSuccess: (_, { submissionId }) => {
      toast.success("Submission approved", `#${submissionId.slice(0, 8)}`);
      queryClient.invalidateQueries({ queryKey: ["verificationQueue"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardStats"] });
    },
    onError: (_, { submissionId }) => {
      toast.error("Failed to approve submission", "Please try again.");
      // Roll back optimistic removal
      setRemovedIds((prev) => {
        const next = new Set(prev);
        next.delete(submissionId);
        return next;
      });
    },
    onSettled: () => {
      setPendingAction(null);
    },
  });

  const rejectMutation = useMutation({
    mutationFn: ({ submissionId }) => rejectSubmission(actor, submissionId),
    onMutate: ({ submissionId }) => {
      setPendingAction(submissionId);
      setRemovedIds((prev) => new Set([...prev, submissionId]));
    },
    onSuccess: (_, { submissionId }) => {
      toast.success("Submission rejected", `#${submissionId.slice(0, 8)}`);
      queryClient.invalidateQueries({ queryKey: ["verificationQueue"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardStats"] });
    },
    onError: (_, { submissionId }) => {
      toast.error("Failed to reject submission", "Please try again.");
      setRemovedIds((prev) => {
        const next = new Set(prev);
        next.delete(submissionId);
        return next;
      });
    },
    onSettled: () => {
      setPendingAction(null);
    },
  });

  function handleApprove(item) {
    const allowed = canActOnScope({
      buildingId: item.submission?.buildingId,
      wardId: item.submission?.wardId,
    });
    if (!allowed) {
      toast.error(
        "Permission denied",
        "You can only review submissions within your assigned scope.",
      );
      return;
    }
    approveMutation.mutate({ submissionId: item.submissionId });
  }

  function handleReject(item) {
    const allowed = canActOnScope({
      buildingId: item.submission?.buildingId,
      wardId: item.submission?.wardId,
    });
    if (!allowed) {
      toast.error(
        "Permission denied",
        "You can only review submissions within your assigned scope.",
      );
      return;
    }
    rejectMutation.mutate({ submissionId: item.submissionId });
  }

  return (
    <div className="flex-1 p-6 lg:p-8">
      {/* Header */}
      <div className="mb-7 flex items-center justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Review &amp; Action
          </p>
          <div className="flex items-center gap-3">
            <h1 className="font-display text-2xl font-bold text-foreground">
              Verification Queue
            </h1>
            {!isLoading && queue.length > 0 && (
              <Badge
                className="bg-accent text-accent-foreground tabular-nums"
                data-ocid="queue-count-badge"
              >
                {queue.length} pending
              </Badge>
            )}
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setRemovedIds(new Set());
            refetch();
          }}
          disabled={isRefetching}
          className="gap-2"
          data-ocid="queue-refresh-btn"
        >
          <RefreshCw size={14} className={isRefetching ? "animate-spin" : ""} />
          Refresh
        </Button>
      </div>

      {/* Scope hint for managers */}
      {isManager && (scope.buildingId || scope.wardId) && (
        <div className="mb-5 flex items-center gap-2 rounded-lg border border-border bg-muted/40 px-4 py-2.5 text-sm text-muted-foreground">
          <MapPin size={14} className="shrink-0" />
          Showing queue for{" "}
          <span className="font-medium text-foreground">
            {scope.buildingId
              ? `Building ${scope.buildingId}`
              : `Ward ${scope.wardId}`}
          </span>
        </div>
      )}

      {/* States */}
      {isError ? (
        <ErrorState
          title="Failed to load queue"
          description="Could not fetch the verification queue. Check your connection and try again."
          onRetry={refetch}
          data-ocid="queue-error"
        />
      ) : isLoading ? (
        <div className="space-y-4" data-ocid="queue-loading">
          {["sk1", "sk2", "sk3"].map((k) => (
            <QueueCardSkeleton key={k} />
          ))}
        </div>
      ) : queue.length === 0 ? (
        <EmptyState
          icon={<CheckCircle size={28} className="text-primary" />}
          title="Queue is clear"
          description="All submissions have been reviewed. New items will appear here automatically."
          data-ocid="queue-empty"
        />
      ) : (
        <div className="space-y-4" data-ocid="queue-list">
          <p className="text-sm text-muted-foreground">
            {queue.length} item{queue.length !== 1 ? "s" : ""} awaiting review
          </p>
          {queue.map((item) => (
            <QueueCard
              key={item.submissionId}
              item={item}
              onApprove={handleApprove}
              onReject={handleReject}
              pendingAction={pendingAction}
            />
          ))}
        </div>
      )}
    </div>
  );
}
