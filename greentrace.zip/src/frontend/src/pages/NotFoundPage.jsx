import { Button } from "@/components/ui/button";
import { Link } from "@tanstack/react-router";
import { Home, Leaf } from "lucide-react";
import { ROUTES } from "../constants/routes";

export function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background px-6 text-center">
      <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-muted">
        <Leaf size={32} className="text-primary" />
      </div>
      <h1 className="font-display text-6xl font-bold text-foreground">404</h1>
      <p className="mt-2 text-lg font-medium text-foreground">Page not found</p>
      <p className="mt-1.5 max-w-sm text-sm text-muted-foreground">
        The page you were looking for doesn&apos;t exist or has been moved.
      </p>
      <Button asChild className="mt-8 gap-2">
        <Link to={ROUTES.DASHBOARD}>
          <Home size={16} />
          Back to Dashboard
        </Link>
      </Button>
    </div>
  );
}
