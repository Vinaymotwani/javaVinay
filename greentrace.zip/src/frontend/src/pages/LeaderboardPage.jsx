import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useQuery } from "@tanstack/react-query";
import { Trophy } from "lucide-react";
import { useState } from "react";
import { EmptyState } from "../components/common/EmptyState";
import { ErrorState } from "../components/common/ErrorState";
import { useRole } from "../hooks/useRole";
import { useBackendActor } from "../services/backend";
import { fetchLeaderboard } from "../services/leaderboardService";

const PERIOD_OPTIONS = [
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
  { value: "allTime", label: "All Time" },
];

const SCOPE_OPTIONS = [
  { value: "global", label: "Global" },
  { value: "building", label: "By Building" },
  { value: "ward", label: "By Ward" },
];

function RankCell({ rank }) {
  const n = Number(rank);
  const medals = ["🥇", "🥈", "🥉"];
  if (n <= 3) {
    return (
      <span className="text-base" role="img" aria-label={`Rank ${n}`}>
        {medals[n - 1]}
      </span>
    );
  }
  return (
    <span className="font-mono text-sm font-semibold text-muted-foreground">
      {n}
    </span>
  );
}

const ROW_SKELETON_KEYS = [
  "rank",
  "user",
  "building",
  "ward",
  "points",
  "streak",
  "approved",
];

function RowSkeleton() {
  return (
    <TableRow>
      {ROW_SKELETON_KEYS.map((k) => (
        <TableCell key={k}>
          <Skeleton className="h-4 w-full" />
        </TableCell>
      ))}
    </TableRow>
  );
}

function truncatePrincipal(principal) {
  if (!principal) return "—";
  const str = String(principal);
  if (str.length <= 16) return str;
  return `${str.slice(0, 8)}…${str.slice(-6)}`;
}

export function LeaderboardPage() {
  const { actor, isFetching } = useBackendActor();
  const {
    isAdmin,
    isManager,
    buildingId: managerBuildingId,
    wardId: managerWardId,
  } = useRole();

  const isManagerLocked = isManager && !isAdmin;

  // For managers, lock scope to their assignment
  const defaultScope = isManagerLocked
    ? managerBuildingId
      ? "building"
      : managerWardId
        ? "ward"
        : "global"
    : "global";

  const defaultScopeId = isManagerLocked
    ? managerBuildingId || managerWardId || ""
    : "";

  const [scopeType, setScopeType] = useState(defaultScope);
  const [scopeId, setScopeId] = useState(defaultScopeId);
  const [period, setPeriod] = useState("weekly");

  function handleScopeTypeChange(val) {
    setScopeType(val);
    // Reset scopeId when scope type changes (for admins)
    if (!isManagerLocked) setScopeId("");
  }

  const resolvedScopeId = scopeType !== "global" && scopeId ? scopeId : null;

  const {
    data: entries = [],
    isLoading,
    isError,
    refetch,
  } = useQuery({
    queryKey: ["leaderboard", scopeType, resolvedScopeId, period],
    queryFn: () =>
      fetchLeaderboard(actor, scopeType, resolvedScopeId, period, 20),
    enabled: !!actor && !isFetching,
  });

  const showScopeInput = scopeType === "building" || scopeType === "ward";
  const scopeInputLabel = scopeType === "building" ? "Building ID" : "Ward ID";

  const activePeriodLabel = PERIOD_OPTIONS.find(
    (o) => o.value === period,
  )?.label;
  const activeScopeLabel = SCOPE_OPTIONS.find(
    (o) => o.value === scopeType,
  )?.label;

  return (
    <div className="flex-1 p-6 lg:p-8">
      {/* Page header */}
      <div className="mb-7 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Trophy size={20} aria-hidden="true" />
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Resident Rankings
          </p>
          <h1 className="font-display text-2xl font-bold text-foreground">
            Leaderboard
          </h1>
        </div>
      </div>

      {/* Filter bar */}
      <div
        className="mb-6 flex flex-wrap items-end gap-4 rounded-xl border border-border bg-card p-4 shadow-card"
        data-ocid="leaderboard-filters"
      >
        {/* Scope filter */}
        <div className="flex flex-col gap-1.5">
          <Label
            htmlFor="scope-select"
            className="text-xs font-medium text-muted-foreground"
          >
            Scope
          </Label>
          <Select
            value={scopeType}
            onValueChange={handleScopeTypeChange}
            disabled={isManagerLocked}
          >
            <SelectTrigger
              id="scope-select"
              className="w-40"
              data-ocid="leaderboard-scope-select"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SCOPE_OPTIONS.filter((o) => {
                if (isManagerLocked) return o.value === defaultScope;
                return true;
              }).map((o) => (
                <SelectItem key={o.value} value={o.value}>
                  {o.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Scope ID input */}
        {showScopeInput && (
          <div className="flex flex-col gap-1.5">
            <Label
              htmlFor="scope-id-input"
              className="text-xs font-medium text-muted-foreground"
            >
              {scopeInputLabel}
            </Label>
            <Input
              id="scope-id-input"
              value={scopeId}
              onChange={(e) => setScopeId(e.target.value)}
              placeholder={`Enter ${scopeInputLabel.toLowerCase()}…`}
              className="w-44"
              disabled={isManagerLocked}
              data-ocid="leaderboard-scope-id-input"
            />
          </div>
        )}

        {/* Period filter */}
        <div className="flex flex-col gap-1.5">
          <Label
            htmlFor="period-select"
            className="text-xs font-medium text-muted-foreground"
          >
            Period
          </Label>
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger
              id="period-select"
              className="w-36"
              data-ocid="leaderboard-period-select"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PERIOD_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>
                  {o.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Active filter pills */}
        <div className="ml-auto flex items-center gap-2 self-end pb-0.5">
          <Badge variant="secondary" className="text-xs">
            {activeScopeLabel}
            {resolvedScopeId ? ` · ${resolvedScopeId}` : ""}
          </Badge>
          <Badge variant="outline" className="text-xs">
            {activePeriodLabel}
          </Badge>
          {isManagerLocked && (
            <Badge variant="outline" className="text-xs text-muted-foreground">
              Scoped view
            </Badge>
          )}
        </div>
      </div>

      {/* Table */}
      {isError ? (
        <ErrorState
          title="Failed to load leaderboard"
          description="Could not fetch ranking data. Please try again."
          onRetry={refetch}
          data-ocid="leaderboard-error"
        />
      ) : (
        <div className="overflow-hidden rounded-xl border border-border bg-card shadow-card">
          <Table data-ocid="leaderboard-table">
            <TableHeader>
              <TableRow className="bg-muted/40 hover:bg-muted/40">
                <TableHead className="w-16 text-center text-xs uppercase tracking-wider">
                  Rank
                </TableHead>
                <TableHead className="text-xs uppercase tracking-wider">
                  User ID
                </TableHead>
                <TableHead className="text-xs uppercase tracking-wider">
                  Building
                </TableHead>
                <TableHead className="text-xs uppercase tracking-wider">
                  Ward
                </TableHead>
                <TableHead className="text-right text-xs uppercase tracking-wider">
                  Points
                </TableHead>
                <TableHead className="text-right text-xs uppercase tracking-wider">
                  Streak
                </TableHead>
                <TableHead className="text-right text-xs uppercase tracking-wider">
                  Approved
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                ["s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8"].map((k) => (
                  <RowSkeleton key={k} />
                ))
              ) : entries.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="p-0">
                    <EmptyState
                      icon={
                        <Trophy size={28} className="text-muted-foreground" />
                      }
                      title="No leaderboard data for this period"
                      description="Try adjusting the scope or period to see rankings."
                      data-ocid="leaderboard-empty"
                    />
                  </TableCell>
                </TableRow>
              ) : (
                entries.map((entry, idx) => {
                  const rank = entry.rank ?? idx + 1;
                  const streak = Number(entry.streak ?? 0);
                  return (
                    <TableRow
                      key={entry.userId?.toString() ?? idx}
                      className="transition-colors hover:bg-muted/30"
                      data-ocid={`leaderboard-row-${idx}`}
                    >
                      <TableCell className="text-center">
                        <RankCell rank={rank} />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 min-w-0">
                          <code className="shrink-0 rounded bg-muted px-1.5 py-0.5 font-mono text-xs text-foreground">
                            {truncatePrincipal(entry.userId)}
                          </code>
                          {entry.displayName?.[0] && (
                            <span className="truncate text-xs text-muted-foreground">
                              {entry.displayName[0]}
                            </span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {entry.buildingId?.[0] ?? "—"}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {entry.wardId?.[0] ?? "—"}
                      </TableCell>
                      <TableCell className="text-right">
                        <span className="font-display text-base font-bold text-foreground tabular-nums">
                          {Number(entry.points ?? 0).toLocaleString()}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <Badge
                          variant={streak >= 7 ? "default" : "secondary"}
                          className="ml-auto font-mono tabular-nums"
                        >
                          {streak}d
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <span className="font-mono text-sm tabular-nums text-foreground">
                          {Number(entry.approvedCount ?? 0).toLocaleString()}
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
