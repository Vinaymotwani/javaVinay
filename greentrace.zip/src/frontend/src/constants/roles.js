export const ADMIN = "admin";
export const MANAGER = "manager";

export const ROLES = {
  ADMIN: "admin",
  MANAGER: "manager",
};

export const ROLE_LABELS = {
  admin: "Administrator",
  manager: "Manager",
};

export const ROLE_COLORS = {
  admin: "bg-primary/20 text-primary",
  manager: "bg-accent/20 text-accent-foreground",
};
