export const DASHBOARD = "/dashboard";
export const QUEUE = "/queue";
export const LEADERBOARD = "/leaderboard";
export const REPORTS = "/reports";

// Object form for backwards compat
export const ROUTES = {
  DASHBOARD,
  QUEUE,
  LEADERBOARD,
  REPORTS,
  NOT_FOUND: "/*",
};
