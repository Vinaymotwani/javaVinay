import { useRoleContext } from "../context/RoleContext";

/**
 * Convenience hook for role-based access.
 * Returns: { role, isAdmin, isManager, scope, buildingId, wardId, canActOnScope, profile, isLoading }
 */
export function useRole() {
  return useRoleContext();
}
