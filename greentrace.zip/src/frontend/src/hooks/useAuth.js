import { useAuthContext } from "../context/AuthContext";

/**
 * Convenience hook for authentication state.
 * Returns: { isAuthenticated, principal, login, logout, isLoading, loading, loginStatus }
 */
export function useAuth() {
  return useAuthContext();
}
