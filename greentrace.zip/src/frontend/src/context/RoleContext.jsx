import { useQuery } from "@tanstack/react-query";
import { createContext, useCallback, useContext, useMemo } from "react";
import { useBackendActor } from "../services/backend";
import { useAuthContext } from "./AuthContext";

const RoleContext = createContext(null);

/**
 * RoleProvider fetches user profile and exposes role, isAdmin, isManager, scope.
 */
export function RoleProvider({ children }) {
  const { isAuthenticated } = useAuthContext();
  const { actor, isFetching } = useBackendActor();

  const { data: profile, isLoading } = useQuery({
    queryKey: ["myProfile"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getMyProfile();
    },
    enabled: isAuthenticated && !!actor && !isFetching,
    staleTime: 5 * 60 * 1000,
  });

  const isAdmin = profile?.role === "admin";
  const isManager = profile?.role === "manager";

  const scope = useMemo(
    () => ({
      buildingId: profile?.buildingId ?? null,
      wardId: profile?.wardId ?? null,
    }),
    [profile],
  );

  /**
   * Check if an action is allowed for the current user's scope.
   * Admins can always act. Managers can only act within their assigned building/ward.
   */
  const canActOnScope = useCallback(
    ({ buildingId, wardId } = {}) => {
      if (isAdmin) return true;
      if (!isManager) return false;
      if (scope.buildingId && buildingId && scope.buildingId !== buildingId)
        return false;
      if (scope.wardId && wardId && scope.wardId !== wardId) return false;
      return true;
    },
    [isAdmin, isManager, scope],
  );

  const value = useMemo(
    () => ({
      profile,
      role: profile?.role ?? null,
      buildingId: scope.buildingId,
      wardId: scope.wardId,
      isAdmin,
      isManager,
      scope,
      canActOnScope,
      isLoading: isLoading || isFetching,
    }),
    [profile, isAdmin, isManager, scope, canActOnScope, isLoading, isFetching],
  );

  return <RoleContext.Provider value={value}>{children}</RoleContext.Provider>;
}

export function useRoleContext() {
  const ctx = useContext(RoleContext);
  if (!ctx) throw new Error("useRoleContext must be used within RoleProvider");
  return ctx;
}
