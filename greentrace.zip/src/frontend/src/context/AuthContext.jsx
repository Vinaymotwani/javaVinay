import { useInternetIdentity } from "@caffeineai/core-infrastructure";
import { createContext, useContext, useEffect, useMemo, useState } from "react";

const AuthContext = createContext(null);

const INIT_TIMEOUT_MS = 3000;

/**
 * AuthProvider wraps the app and exposes:
 *   isAuthenticated, principal, login, logout, isLoading, loading
 *
 * isLoading (and its alias loading) is derived solely from II isInitializing,
 * with a hard 3s timeout so the app never hangs on canister readiness.
 */
export function AuthProvider({ children }) {
  const { identity, login, clear, isInitializing, loginStatus } =
    useInternetIdentity();

  const [timedOut, setTimedOut] = useState(false);

  useEffect(() => {
    if (!isInitializing) return;
    const id = setTimeout(() => setTimedOut(true), INIT_TIMEOUT_MS);
    return () => clearTimeout(id);
  }, [isInitializing]);

  const isLoading = isInitializing && !timedOut;

  const value = useMemo(
    () => ({
      isAuthenticated: !!identity,
      principal: identity?.getPrincipal() ?? null,
      login,
      logout: clear,
      isLoading,
      // alias for backwards compat
      loading: isLoading,
      loginStatus,
    }),
    [identity, login, clear, isLoading, loginStatus],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuthContext() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuthContext must be used within AuthProvider");
  return ctx;
}
