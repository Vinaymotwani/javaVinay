/**
 * Stats service — wraps backend calls for dashboard and scope stats.
 */

/**
 * Fetch dashboard-level summary stats.
 * @param {object} actor
 * @param {{ buildingId?: string|null, wardId?: string|null }|null} scope
 * @returns {Promise<DashboardStats>}
 */
export async function fetchDashboardStats(actor, scope) {
  return actor.getDashboardStats(
    scope?.buildingId ?? null,
    scope?.wardId ?? null,
  );
}

/**
 * Fetch daily stats for a given scope (building or ward).
 * @param {object} actor
 * @param {"building"|"ward"} scopeType
 * @param {string} scopeId
 * @returns {Promise<Array>}
 */
export async function fetchScopeStats(actor, scopeType, scopeId) {
  return actor.getScopeStats(scopeType, scopeId);
}
