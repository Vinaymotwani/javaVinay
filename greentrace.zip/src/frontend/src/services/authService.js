/**
 * Auth service — thin wrappers around the II hook values.
 * Business logic lives here; components call these helpers.
 */

/**
 * Trigger Internet Identity login (one-click, no username/password).
 * Pass the `login` fn from useAuth().
 * @param {Function} login
 */
export function loginWithII(login) {
  login();
}

/**
 * Log out the current user.
 * @param {Function} logout
 */
export function logoutUser(logout) {
  logout();
}
