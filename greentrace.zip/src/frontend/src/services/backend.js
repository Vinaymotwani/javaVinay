import { useActor } from "@caffeineai/core-infrastructure";

/**
 * Returns the typed backend actor and loading state.
 * Wrap calls with: const { actor, isFetching } = useBackendActor();
 * Always gate queries with enabled: !!actor && !isFetching
 */
export function useBackendActor() {
  return useActor();
}
