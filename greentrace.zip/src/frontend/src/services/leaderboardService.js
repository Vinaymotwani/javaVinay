/**
 * Leaderboard service — wraps backend calls for leaderboard data.
 */

/**
 * Fetch leaderboard entries.
 * @param {object} actor
 * @param {"global"|"ward"|"building"} scopeType
 * @param {string|null} scopeId
 * @param {"weekly"|"monthly"|"allTime"} period
 * @param {number} limit
 * @returns {Promise<Array>}
 */
export async function fetchLeaderboard(
  actor,
  scopeType = "global",
  scopeId = null,
  period = "weekly",
  limit = 20,
) {
  return actor.getLeaderboard(scopeType, scopeId, period, BigInt(limit));
}
