/**
 * Queue service — wraps backend actor calls for the verification queue.
 */

/**
 * Fetch pending verification queue items, scoped by manager's building/ward.
 * @param {object} actor - backend actor
 * @param {{ buildingId?: string|null, wardId?: string|null }} scope
 * @returns {Promise<Array>}
 */
export async function fetchVerificationQueue(actor, scope = {}) {
  return actor.getVerificationQueue(
    scope.buildingId ?? null,
    scope.wardId ?? null,
  );
}

/**
 * Approve a submission.
 * @param {object} actor
 * @param {string} submissionId
 * @returns {Promise<boolean>}
 */
export async function approveSubmission(actor, submissionId) {
  return actor.approveSubmission(submissionId, null);
}

/**
 * Reject a submission.
 * @param {object} actor
 * @param {string} submissionId
 * @returns {Promise<boolean>}
 */
export async function rejectSubmission(actor, submissionId) {
  return actor.rejectSubmission(submissionId, null);
}
