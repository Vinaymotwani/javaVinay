// Re-export ProtectedRoute from this index for cleaner imports
export { ProtectedRoute } from "./ProtectedRoute";
