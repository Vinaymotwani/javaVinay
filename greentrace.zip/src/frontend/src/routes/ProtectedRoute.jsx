import { LoadingSpinner } from "../components/common/LoadingSpinner";
import { SignInPrompt } from "../components/common/SignInPrompt";
import { useAuth } from "../hooks/useAuth";

/**
 * ProtectedRoute — shows SignInPrompt for unauthenticated users (NO redirect to /login).
 * Shows a fullscreen spinner while auth is initializing.
 */
export function ProtectedRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return <LoadingSpinner fullscreen label="Authenticating…" />;
  }

  if (!isAuthenticated) {
    return <SignInPrompt />;
  }

  return children;
}
