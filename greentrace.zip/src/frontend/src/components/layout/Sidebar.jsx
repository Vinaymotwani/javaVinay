import { cn } from "@/lib/utils";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  CheckSquare,
  LayoutDashboard,
  Leaf,
  LogOut,
  Trophy,
} from "lucide-react";
import { ROLE_LABELS } from "../../constants/roles";
import { ROUTES } from "../../constants/routes";
import { useAuth } from "../../hooks/useAuth";
import { useRole } from "../../hooks/useRole";

const NAV_ITEMS = [
  {
    label: "Dashboard",
    href: ROUTES.DASHBOARD,
    icon: LayoutDashboard,
    ocid: "nav-dashboard",
  },
  {
    label: "Verification Queue",
    href: ROUTES.QUEUE,
    icon: CheckSquare,
    ocid: "nav-queue",
  },
  {
    label: "Leaderboard",
    href: ROUTES.LEADERBOARD,
    icon: Trophy,
    ocid: "nav-leaderboard",
  },
  {
    label: "Reports",
    href: ROUTES.REPORTS,
    icon: BarChart3,
    ocid: "nav-reports",
  },
];

export function Sidebar({ onNavigate }) {
  const { logout } = useAuth();
  const { role } = useRole();
  const routerState = useRouterState();
  const currentPath = routerState.location.pathname;

  function isActive(href) {
    return (
      currentPath === href || (href !== "/" && currentPath.startsWith(href))
    );
  }

  return (
    <aside className="flex h-full w-64 flex-col bg-sidebar text-sidebar-foreground">
      {/* Logo */}
      <div className="flex items-center gap-3 border-b border-sidebar-border px-6 py-5">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-sidebar-primary shrink-0">
          <Leaf
            size={18}
            className="text-sidebar-primary-foreground"
            aria-hidden="true"
          />
        </div>
        <div>
          <p className="font-display text-base font-semibold leading-tight text-sidebar-foreground">
            GreenTrace
          </p>
          <p className="text-[11px] text-sidebar-accent-foreground opacity-70">
            Municipal Bureau
          </p>
        </div>
      </div>

      {/* Navigation */}
      <nav
        className="flex-1 overflow-y-auto px-3 py-4"
        aria-label="Main navigation"
        data-ocid="sidebar-nav"
      >
        <ul className="space-y-1">
          {NAV_ITEMS.map((item) => {
            const active = isActive(item.href);
            return (
              <li key={item.href}>
                <Link
                  to={item.href}
                  onClick={onNavigate}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-smooth",
                    active
                      ? "bg-sidebar-primary/15 text-sidebar-primary"
                      : "text-sidebar-accent-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground",
                  )}
                  data-ocid={item.ocid}
                  aria-current={active ? "page" : undefined}
                >
                  <item.icon
                    size={18}
                    className={cn(
                      "shrink-0",
                      active ? "text-sidebar-primary" : "opacity-70",
                    )}
                    aria-hidden="true"
                  />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Role badge + Logout */}
      <div className="border-t border-sidebar-border px-4 py-4">
        {role && (
          <div className="mb-3 flex items-center gap-2">
            <span
              className={cn(
                "inline-flex items-center rounded-md px-2.5 py-1 text-xs font-semibold uppercase tracking-wider",
                role === "admin"
                  ? "bg-sidebar-primary/20 text-sidebar-primary"
                  : "bg-accent/20 text-accent-foreground",
              )}
              data-ocid="sidebar-role-badge"
            >
              {ROLE_LABELS[role] ?? role}
            </span>
          </div>
        )}
        <button
          type="button"
          onClick={logout}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-accent-foreground transition-smooth hover:bg-destructive/10 hover:text-destructive"
          data-ocid="sidebar-logout-btn"
        >
          <LogOut size={18} className="shrink-0" aria-hidden="true" />
          Sign out
        </button>
      </div>
    </aside>
  );
}
