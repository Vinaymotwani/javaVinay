import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { Toaster } from "@/components/ui/sonner";
import { Menu } from "lucide-react";
import { useState } from "react";
import { Sidebar } from "./Sidebar";

/**
 * Main authenticated layout: dark sidebar + white content area.
 * Desktop (lg+): persistent sidebar. Mobile/tablet: sheet drawer via hamburger.
 */
export function Layout({ children }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Desktop sidebar — fixed left */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:shrink-0 bg-sidebar border-r border-sidebar-border">
        <Sidebar />
      </aside>

      {/* Mobile sidebar sheet */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent
          side="left"
          className="w-64 p-0 bg-sidebar border-r border-sidebar-border"
        >
          <Sidebar onNavigate={() => setMobileOpen(false)} />
        </SheetContent>
      </Sheet>

      {/* Main content */}
      <main className="flex flex-1 flex-col overflow-y-auto bg-background min-w-0">
        {/* Mobile top bar with hamburger */}
        <div className="flex items-center gap-3 border-b border-border bg-card px-4 py-3 lg:hidden shrink-0">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileOpen(true)}
            aria-label="Open navigation"
            data-ocid="mobile-menu-btn"
          >
            <Menu size={20} />
          </Button>
          <span className="font-display text-sm font-semibold text-foreground">
            GreenTrace
          </span>
        </div>

        {children}
      </main>

      <Toaster richColors position="top-right" />
    </div>
  );
}
