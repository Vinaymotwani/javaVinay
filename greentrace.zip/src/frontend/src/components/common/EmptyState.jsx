import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { InboxIcon } from "lucide-react";

/**
 * Empty state with optional illustration, headline, description, and CTA.
 * @param {{ icon?: React.ReactNode, title: string, description?: string, action?: { label: string, onClick: Function }, className?: string }} props
 */
export function EmptyState({
  icon,
  title,
  description,
  action,
  className,
  "data-ocid": dataOcid,
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center py-16 px-8 text-center",
        className,
      )}
      data-ocid={dataOcid}
    >
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted text-muted-foreground">
        {icon ?? <InboxIcon size={28} />}
      </div>
      <h3 className="mb-1 text-base font-semibold text-foreground">{title}</h3>
      {description && (
        <p className="mb-6 max-w-sm text-sm text-muted-foreground">
          {description}
        </p>
      )}
      {action && (
        <Button onClick={action.onClick} data-ocid="empty-state-cta">
          {action.label}
        </Button>
      )}
    </div>
  );
}
