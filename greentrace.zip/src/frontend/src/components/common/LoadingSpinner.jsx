import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

/**
 * Fullscreen or inline loading spinner.
 * @param {{ fullscreen?: boolean, size?: number, className?: string, label?: string }} props
 */
export function LoadingSpinner({
  fullscreen = false,
  size = 24,
  className,
  label = "Loading…",
}) {
  if (fullscreen) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <Loader2
            size={40}
            className="animate-spin text-primary"
            aria-hidden="true"
          />
          <p className="text-sm text-muted-foreground">{label}</p>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("flex items-center justify-center py-12", className)}>
      <Loader2
        size={size}
        className="animate-spin text-primary"
        aria-hidden="true"
      />
      <span className="sr-only">{label}</span>
    </div>
  );
}
