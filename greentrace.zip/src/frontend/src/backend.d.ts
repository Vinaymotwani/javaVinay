import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface QueueItem {
    tags: Array<string>;
    submissionId: SubmissionId;
    flagged: boolean;
    submission: Submission;
}
export interface LeaderboardEntry {
    streak: bigint;
    displayName?: string;
    userId: UserId;
    approvedCount: bigint;
    rank: bigint;
    wardId?: WardId;
    buildingId?: BuildingId;
    points: bigint;
}
export type WardId = string;
export type Timestamp = bigint;
export interface DailyStats {
    scopeType: ScopeType;
    pending: bigint;
    date: string;
    scopeId: string;
    totalSubmissions: bigint;
    approved: bigint;
    rejected: bigint;
    points: bigint;
}
export interface RedemptionRequest {
    id: RequestId;
    status: string;
    userId: UserId;
    rewardId: RewardId;
    requestedAt: Timestamp;
}
export type BuildingId = string;
export interface RewardItem {
    id: RewardId;
    active: boolean;
    pointsRequired: bigint;
    name: string;
    description: string;
    stock: bigint;
}
export interface DashboardStats {
    complianceRate: number;
    pending: bigint;
    totalSubmissions: bigint;
    approved: bigint;
    rejected: bigint;
}
export interface UserRecord {
    id: UserId;
    createdAt: Timestamp;
    role: Role;
    wardId?: WardId;
    buildingId?: BuildingId;
}
export type SubmissionId = string;
export type UserId = Principal;
export type RewardId = string;
export interface RewardInput {
    pointsRequired: bigint;
    name: string;
    description: string;
    stock: bigint;
}
export type RequestId = string;
export interface Submission {
    id: SubmissionId;
    status: SubmissionStatus;
    wasteType: string;
    submittedAt: Timestamp;
    submittedBy: UserId;
    reviewedAt?: Timestamp;
    reviewedBy?: UserId;
    imageUrl?: string;
    notes?: string;
    wardId: WardId;
    buildingId: BuildingId;
}
export enum Period {
    allTime = "allTime",
    monthly = "monthly",
    weekly = "weekly"
}
export enum Role {
    manager = "manager",
    admin = "admin"
}
export enum ScopeType {
    ward = "ward",
    building = "building",
    global = "global"
}
export enum SubmissionStatus {
    pending_review = "pending_review",
    approved = "approved",
    rejected = "rejected"
}
export interface backendInterface {
    addRewardItem(input: RewardInput): Promise<RewardId>;
    approveSubmission(submissionId: SubmissionId, notes: string | null): Promise<boolean>;
    getDashboardStats(buildingId: BuildingId | null, wardId: WardId | null): Promise<DashboardStats>;
    getLeaderboard(scopeType: ScopeType, scopeId: string | null, period: Period, limit: bigint): Promise<Array<LeaderboardEntry>>;
    getMyProfile(): Promise<UserRecord | null>;
    getScopeStats(scopeType: ScopeType, scopeId: string): Promise<Array<DailyStats>>;
    getSubmissions(status: SubmissionStatus | null, buildingId: BuildingId | null, wardId: WardId | null, limit: bigint | null): Promise<Array<Submission>>;
    getUserProfile(target: UserId): Promise<UserRecord | null>;
    getVerificationQueue(buildingId: BuildingId | null, wardId: WardId | null): Promise<Array<QueueItem>>;
    listRedemptionRequests(userId: UserId | null): Promise<Array<RedemptionRequest>>;
    listRewardCatalog(): Promise<Array<RewardItem>>;
    listUsers(): Promise<Array<UserRecord>>;
    redeemReward(rewardId: RewardId): Promise<RequestId>;
    registerMe(): Promise<UserRecord>;
    rejectSubmission(submissionId: SubmissionId, notes: string | null): Promise<boolean>;
    setUserRole(target: UserId, role: Role, buildingId: BuildingId | null, wardId: WardId | null): Promise<void>;
}
