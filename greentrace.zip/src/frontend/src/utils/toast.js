import { toast as sonnerToast } from "sonner";

export const toast = {
  success: (message, description) =>
    sonnerToast.success(message, { description }),

  error: (message, description) =>
    sonnerToast.error(message, {
      description: description ?? "Please try again.",
    }),

  info: (message, description) => sonnerToast.info(message, { description }),

  loading: (message) => sonnerToast.loading(message),

  dismiss: (id) => sonnerToast.dismiss(id),
};
