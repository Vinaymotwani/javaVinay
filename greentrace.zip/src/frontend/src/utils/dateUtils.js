/**
 * Format a Date or ISO string to a readable date string.
 * @param {Date|string|number} date
 * @returns {string}
 */
export function formatDate(date) {
  if (!date) return "—";
  const d = new Date(typeof date === "number" ? date : date);
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

/**
 * Format a Date or ISO string to a relative time string (e.g. "3 minutes ago").
 * @param {Date|string|number} date
 * @returns {string}
 */
export function formatRelative(date) {
  if (!date) return "—";
  const d = new Date(typeof date === "number" ? date : date);
  const now = new Date();
  const diffMs = now - d;
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffSec < 60) return "just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHr < 24) return `${diffHr}h ago`;
  if (diffDay < 7) return `${diffDay}d ago`;
  return formatDate(d);
}

/**
 * Format a BigInt nanosecond timestamp from the IC to a readable date.
 * @param {bigint|number|null|undefined} ts
 * @returns {string}
 */
export function formatTimestamp(ts) {
  if (ts === null || ts === undefined) return "—";
  // IC timestamps are in nanoseconds
  const ms = typeof ts === "bigint" ? Number(ts / BigInt(1_000_000)) : ts;
  return formatDate(new Date(ms));
}

/**
 * Format a BigInt nanosecond timestamp to a relative time string.
 * @param {bigint|number|null|undefined} ts
 * @returns {string}
 */
export function formatTimestampRelative(ts) {
  if (ts === null || ts === undefined) return "—";
  const ms = typeof ts === "bigint" ? Number(ts / BigInt(1_000_000)) : ts;
  return formatRelative(new Date(ms));
}
