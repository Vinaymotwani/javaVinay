# Design Brief: GreenTrace Admin Dashboard

## Tone & Purpose
Municipal government waste monitoring dashboard. Utilitarian, authoritative, clarity-first. Information density with zero decoration.

## Palette
| Token | OKLCH | Role |
| --- | --- | --- |
| Primary (Forest Green) | 0.48 0.19 142 (light) / 0.58 0.19 142 (dark) | Approval CTAs, sustainability messaging |
| Accent (Orange) | 0.62 0.19 47 (light) / 0.68 0.19 47 (dark) | Flagged, pending review, urgent |
| Destructive (Red) | 0.52 0.21 22 (light) / 0.62 0.19 22 (dark) | Rejection, errors, violations |
| Sidebar (Charcoal) | 0.2 0 0 (light) / 0.13 0 0 (dark) | Dark navigation anchor, authority |
| Background | 0.98 0 0 (light) / 0.12 0 0 (dark) | Clean content canvas |
| Muted (Grays) | 0.92 0 0 (light) / 0.2 0 0 (dark) | Secondary data, disabled states |

## Typography
| Role | Font | Scale |
| --- | --- | --- |
| Display | Bricolage Grotesque 600 | 24px (title), 18px (card header) |
| Body | General Sans 400 | 14px (standard), 16px (copy), 12px (caption) |
| Mono | Geist Mono 400 | 14px (data, IDs, codes) |

## Elevation & Depth
- Sidebar: Solid dark anchor, 1px border-r divider
- Header: White bg with 1px border-b
- Cards: `shadow-card` (2px 8px), `shadow-elevated` (4px 16px) for layers
- No gradients, no textures

## Structural Zones
| Zone | Treatment |
| --- | --- |
| Sidebar | Dark charcoal, fixed 16rem, white text, forest green active items |
| Header | White background, subtle lower border, role badge right |
| Content Grid | bg-background, padding 24px, 2-4 col layout |
| Stat Cards | bg-card, 12px radius, green numbers, gray labels |
| Verification Queue | Photo thumbnails, green/red buttons, high contrast |
| Leaderboard | Bordered table, neutral rows, mono rank/points |

## Spacing
- 4px grid unit, 8/16/24/32px padding increments
- 16px card gaps (md), 24px (lg)
- 8px within-card gutters

## Component Patterns
- Buttons: Green (primary action), Red (reject/delete), Gray (secondary), Orange (warning/flag)
- Tables: Neutral grid, mono numeric columns, subtle row dividers
- Badges: Role badge in sidebar, status badges on queue items
- Forms: Input `bg-input`, focus ring `ring-primary`

## Motion
- `transition-smooth` (0.3s ease) on interactive elements, hover state lift
- No entrance animations, static layout priority
- Functional feedback only (state changes, focus indicators)

## Constraints
- Sidebar always visible
- No decorative animations or gradients
- High contrast for authority and readability
- Max 1400px on 2xl screens
- Municipal government aesthetic: utilitarian > ornamental

## Signature Detail
Dark sidebar + bright content creates visual hierarchy and authority. Functional color spots (green approve, red reject, orange flag) enable at-a-glance verification status. No decoration ensures municipal trust and clarity.

